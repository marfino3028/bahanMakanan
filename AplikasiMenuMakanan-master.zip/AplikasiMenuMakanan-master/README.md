## KELAS MOBILE PROGRAMMING BBPLK BEKASI 2020
**Challenge Aplikasi Menu Makanan menggunakan Kotlin**
Aplikasi Menu Makanan dapat menghitung makanan apa saja yang di checklist beserta quantitynya, kemudian bisa menghitung pembayarannya

### Screenshoot Aplikasi Color My View
![Screenshot](https://github.com/nurzainpradana/AplikasiMenuMakanan/blob/master/screenshoot/Screenshot_1604308580.png?raw=true)
![Screenshot](https://github.com/nurzainpradana/AplikasiMenuMakanan/blob/master/screenshoot/Screenshot_1604308586.png?raw=true)
